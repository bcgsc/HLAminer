./updateHLAcoding.sh
./updateHLAgenomic.sh
./updateHLA-I_II_coding.sh
./updateHLA-I_II_genomic.sh
./update_p_designation.sh

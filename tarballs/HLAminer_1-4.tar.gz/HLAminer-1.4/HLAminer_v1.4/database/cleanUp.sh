rm -rf *_gen.fasta
rm -rf *_nuc.fasta

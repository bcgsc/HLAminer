rm -rf hla_nom_p.txt 
wget http://hla.alleles.org/wmda/hla_nom_p.txt

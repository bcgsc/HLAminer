rm -rf *.sam
rm -rf *.sai
rm -rf TASRhla*
rm -rf *.coord
rm -rf error.log
rm -rf formatdb.log
